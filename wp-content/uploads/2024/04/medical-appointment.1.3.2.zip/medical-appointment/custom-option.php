<?php

    $medical_appointment_theme_css= "";

    /*--------------------------- Scroll to top positions -------------------*/

    $medical_appointment_scroll_position = get_theme_mod( 'medical_appointment_scroll_top_position','Right');
    if($medical_appointment_scroll_position == 'Right'){
        $medical_appointment_theme_css .='#button{';
            $medical_appointment_theme_css .='right: 20px;';
        $medical_appointment_theme_css .='}';
    }else if($medical_appointment_scroll_position == 'Left'){
        $medical_appointment_theme_css .='#button{';
            $medical_appointment_theme_css .='left: 20px;';
        $medical_appointment_theme_css .='}';
    }else if($medical_appointment_scroll_position == 'Center'){
        $medical_appointment_theme_css .='#button{';
            $medical_appointment_theme_css .='right: 50%;left: 50%;';
        $medical_appointment_theme_css .='}';
    }

    /*--------------------------- Slider Opacity -------------------*/

    $medical_appointment_theme_lay = get_theme_mod( 'medical_appointment_slider_opacity_color','');
    if($medical_appointment_theme_lay == '0'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.1'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.1';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.2'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.2';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.3'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.3';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.4'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.4';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.5'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.5';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.6'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.6';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.7'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.7';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.8'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.8';
        $medical_appointment_theme_css .='}';
        }else if($medical_appointment_theme_lay == '0.9'){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='opacity:0.9';
        $medical_appointment_theme_css .='}';
        }

    /*---------------------------Slider Height ------------*/

    $medical_appointment_slider_img_height = get_theme_mod('medical_appointment_slider_img_height');
    if($medical_appointment_slider_img_height != false){
        $medical_appointment_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $medical_appointment_theme_css .='height: '.esc_attr($medical_appointment_slider_img_height).';';
        $medical_appointment_theme_css .='}';
    }

    /*--------------------------- Woocommerce Product Border Radius -------------------*/

    $medical_appointment_woo_product_border_radius = get_theme_mod('medical_appointment_woo_product_border_radius', 0);
    if($medical_appointment_woo_product_border_radius != false){
        $medical_appointment_theme_css .='.woocommerce ul.products li.product a img{';
            $medical_appointment_theme_css .='border-radius: '.esc_attr($medical_appointment_woo_product_border_radius).'px;';
        $medical_appointment_theme_css .='}';
    }

    /*---------------- Single post Settings ------------------*/

    $medical_appointment_single_post_navigation_show_hide = get_theme_mod('medical_appointment_single_post_navigation_show_hide',true);
    if($medical_appointment_single_post_navigation_show_hide != true){
        $medical_appointment_theme_css .='.nav-links{';
            $medical_appointment_theme_css .='display: none;';
        $medical_appointment_theme_css .='}';
    }

    /*--------------------------- Woocommerce Product Sale Positions -------------------*/

    $medical_appointment_product_sale = get_theme_mod( 'medical_appointment_woocommerce_product_sale','Right');
    if($medical_appointment_product_sale == 'Right'){
        $medical_appointment_theme_css .='.woocommerce ul.products li.product .onsale{';
            $medical_appointment_theme_css .='left: auto; right: 15px;';
        $medical_appointment_theme_css .='}';
    }else if($medical_appointment_product_sale == 'Left'){
        $medical_appointment_theme_css .='.woocommerce ul.products li.product .onsale{';
            $medical_appointment_theme_css .='left: 15px; right: auto;';
        $medical_appointment_theme_css .='}';
    }else if($medical_appointment_product_sale == 'Center'){
        $medical_appointment_theme_css .='.woocommerce ul.products li.product .onsale{';
            $medical_appointment_theme_css .='right: 50%;left: 50%;';
        $medical_appointment_theme_css .='}';
    }

    /*--------------------------- Footer background image -------------------*/

    $medical_appointment_footer_bg_image = get_theme_mod('medical_appointment_footer_bg_image');
    if($medical_appointment_footer_bg_image != false){
        $medical_appointment_theme_css .='#colophon{';
            $medical_appointment_theme_css .='background: url('.esc_attr($medical_appointment_footer_bg_image).')!important;';
        $medical_appointment_theme_css .='}';
    }

    /*--------------------------- Copyright Background Color -------------------*/

    $medical_appointment_copyright_background_color = get_theme_mod('medical_appointment_copyright_background_color');
    if($medical_appointment_copyright_background_color != false){
        $medical_appointment_theme_css .='.footer_info{';
            $medical_appointment_theme_css .='background-color: '.esc_attr($medical_appointment_copyright_background_color).' !important;';
        $medical_appointment_theme_css .='}';
    } 

    /*--------------------------- Site Title And Tagline Color -------------------*/

    $medical_appointment_logo_title_color = get_theme_mod('medical_appointment_logo_title_color');
    if($medical_appointment_logo_title_color != false){
        $medical_appointment_theme_css .='p.site-title a, .navbar-brand a{';
            $medical_appointment_theme_css .='color: '.esc_attr($medical_appointment_logo_title_color).' !important;';
        $medical_appointment_theme_css .='}';
    }

    $medical_appointment_logo_tagline_color = get_theme_mod('medical_appointment_logo_tagline_color');
    if($medical_appointment_logo_tagline_color != false){
        $medical_appointment_theme_css .='.logo p.site-description, .navbar-brand p{';
            $medical_appointment_theme_css .='color: '.esc_attr($medical_appointment_logo_tagline_color).'  !important;';
        $medical_appointment_theme_css .='}';
    }