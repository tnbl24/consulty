<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => __( 'Changelog', 'bdthemes-element-pack' ),
	'required'           => true,
	'default_activation' => false,
	'has_style' 		 => true,
];
